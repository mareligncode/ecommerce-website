
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>online shoping</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
     rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous">
      <link rel="stylesheet" href="style.css">
      <!-- FontAwesome CDN -->
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet">
<!-- <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> -->

<!-- <script src="https://kit.fontawesome.com/your-unique-kit-code.js" crossorigin="anonymous"></script> -->



</head>
<body>

<section class="services bg-info-subtle py-5 m-2" id="service">
    <div class="container">
     <h2 class="text-center mb-4">my services for males cloth</h2>
      <center>  <h6 style="color:yellow;">are you interested to buy fasion and quality brand? this is for you</h6></center>
       <h5> if you have other interesr rather than this please contact me by using contact page provided below
        <div class="row" id="product-container">
            <!-- Initial Products -->
            <div class="col-sm-4 mb-4 bg-success-subtle" id="product1">
                <div class="card">
                    <img src="images/jeans.jpg" class="card-img-top" alt="Jeans">
                    <div class="card-body">
                        <h5 class="card-title">Jeans</h5>
                        <h5>high quality</h5>

                        <p class="card-text">2500</p>
                    </div>
                </div>
            <button class="btn btn-primary load-more" data-type="Jeans">Load More Styles</button>
          </div>
            <div class="col-sm-4 mb-4 bg-info-subtle" id="product2">
                <div class="card">
                    <img src="images/sh2.jpg" class="card-img-top" alt="Shirt">
                    <div class="card-body">
                        <h5 class="card-title">Shirt</h5>
                        <h5>high quality</h5>

                        <p class="card-text">2000</p>
                    </div>
                </div>
                <button class="btn btn-primary load-more" data-type="Shirt">Load More Styles</button>
            </div>
            <div class="col-sm-4 mb-4 bg-dark-subtle" id="product3">
                <div class="card">
                    <img src="images/jct.jpg" class="card-img-top" alt="Jacket">
                    <div class="card-body">
                        <h5 class="card-title">Jacket</h5>
                        <h5>high quality</h5>

                        <p class="card-text">700</p>
                    </div>
                </div>
                <button class="btn btn-primary load-more" data-type="Jacket">Load More Styles</button>
            </div>
            <div class="col-sm-4 mb-4 bg-warning-subtle" id="product4">
                <div class="card">
                    <img src="images/shoes.jpg" class="card-img-top" alt="Shoes">
                    <div class="card-body">
                        <h5 class="card-title">Shoes</h5>
                        <h5>high quality</h5>
                        <p class="card-text">1200</p>
                    </div>
                </div>
                <button class="btn btn-primary load-more" data-type="Shoes">Load More Styles</button>
            </div>
            <div class="col-sm-4 mb-4 bg-danger-subtle" id="product5">
                <div class="card">
                    <img src="images/T-Shirt.jpg" class="card-img-top" alt="T-Shirt">
                    <div class="card-body">
                        <h5 class="card-title">T-Shirt</h5>
                        <h5>high quality</h5>

                        <p class="card-text">1000</p>
                    </div>
                </div>
                <button class="btn btn-primary load-more" data-type="T-Shirt">Load More Styles</button>
            </div>
            <div class="col-sm-4 mb-4 bg-dark-subtle" id="product6">
                <div class="card">
                    <img src="images/belt.jpg" class="card-img-top" alt="Belt">
                    <div class="card-body">
                        <h5 class="card-title">Belt</h5>
                        <h5>high quality</h5>

                        <p class="card-text">150</p>
                    </div>
                </div>
                <button class="btn btn-primary load-more" data-type="Belt">Load More Styles</button>
            </div>
        </div>

        <div class="my-4">
        
        <form method="post" action="index.php#service" class="my-4">
         <h4>Select Product Options</h4>
            <div class="form-group">
                <label for="size">Size:</label>
                <select id="size" class="form-control" name="size">
                    <option value="S">Small</option>
                    <option value="M">Medium</option>
                    <option value="L">Large</option>
                    <option value="XL">Extra Large</option>
                </select>
            </div>
            <div class="form-group">
                <label for="quality">Quality:</label>
                <select id="quality" class="form-control" name="quality">
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                </select>
            </div>
            <div class="form-group">
                <label for="product-type">Product Type:</label>
                <select id="product-type" class="form-control" name="product_type">
                    <option value="Jeans">Jeans</option>
                    <option value="Shirt">Shirt</option>
                    <option value="Jacket">Jacket</option>
                    <option value="Shoes">Shoes</option>
                    <option value="T-Shirt">T-Shirt</option>
                    <option value="Belt">Belt</option>
                </select>
            </div>
            <div class="form-group">
                <label for="price">full name:</label>
                <!-- <input type="text" id="price" class="form-control" disabled> -->
                <input type="text" id="price" name="price"  
               placeholder="fullname:mobile" class="form-control" >
            </div>
            <button id="submit" class="btn btn-success sub" name="submit">Submit Selection</button>
            <a href="index.php" class="btn btn-primary">home</a>
        if you need to women cloth<a href="main.php" class="btn btn-secondary">women</a> 

        </div>
        
  </form>
  <h5 id="pro"></h5>
    </div>
</section>


<script>
    <?php include 'scripts.js'; ?>
</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
          integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
           crossorigin="anonymous"></script>
</body>
<html>