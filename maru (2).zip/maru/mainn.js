document.addEventListener("DOMContentLoaded", function () {
  // View All functionality for all category buttons
  document.querySelectorAll(".view-all-btn").forEach((button) => {
    button.addEventListener("click", function () {
      const category = this.getAttribute("data-category");
      loadMoreProducts(category);
    });
  });

  // Product data for all categories
  const productsData = {
    jeans: [
      { name: "Skinny Jeans", price: "$49.99", image: "img/w1jeans.jpg" },
      { name: "Bootcut Jeans", price: "$54.99", image: "img/w3jeans.jpg" },
      { name: "High Waist Jeans", price: "$59.99", image: "img/w2jeans.jpg" },
      { name: "Ripped Jeans", price: "$64.99", image: "img/w4jeans.jpg" },
    ],
    shoes: [
      { name: "Running Shoes", price: "$79.99", image: "img/fs1.jpg" },
      { name: "Casual Sneakers", price: "$59.99", image: "img/fs2.jpg" },
      { name: "High Heels", price: "$89.99", image: "img/fs3.jpg" },
      { name: "Boots", price: "$99.99", image: "img/fs4.jpg" },
    ],
    dress: [
      { name: "Summer Dress", price: "$39.99", image: "img/w2dress.jpg" },
      { name: "Evening Gown", price: "$89.99", image: "img/w3dress.jpg" },
      { name: "Casual Dress", price: "$49.99", image: "img/w4dress.jpg" },
      { name: "Party Dress", price: "$69.99", image: "img/w5dress.jpg" },
    ],
    "t-shirt": [
      { name: "Basic T-Shirt", price: "$19.99", image: "img/t1women.jpg" },
      { name: "Graphic Tee", price: "$24.99", image: "img/wtshirts.jpg" },
      { name: "V-Neck T-Shirt", price: "$22.99", image: "img/t3women.jpg" },
      { name: "Long Sleeve Tee", price: "$29.99", image: "img/t4women.jpg" },
    ],
  };

  // Function to load more products for any category
  function loadMoreProducts(category) {
    const modalId = `${category}-modal`;
    let modal = document.getElementById(modalId);

    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement("div");
      modal.id = modalId;
      modal.className = "modal fade";
      modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">All ${category.replace(
                              "-",
                              " "
                            )} Products</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row" id="${category}-products-container">
                                <!-- Products will be loaded here -->
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            `;
      document.body.appendChild(modal);

      // Initialize Bootstrap modal
      const bsModal = new bootstrap.Modal(modal);
      bsModal.show();
    }

    // Get the products container
    const container = document.getElementById(`${category}-products-container`);
    container.innerHTML = ""; // Clear previous content

    // Add products to the container
    if (productsData[category]) {
      productsData[category].forEach((product) => {
        const productHtml = `
                    <div class="col-md-4 mb-4">
                        <div class="card product-card">
                            <img src="${product.image}" class="card-img-top" alt="${product.name}">
                            <div class="card-body">
                                <h5 class="card-title">${product.name}</h5>
                                <p class="card-text">${product.price}</p>
                                <h6>level two</h6>
                            </div>
                        </div>
                    </div>
                `;
        container.innerHTML += productHtml;
      });
    }
  }

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();

      const targetId = this.getAttribute("href");
      if (targetId === "#") return;

      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: "smooth",
        });
      }
    });
  });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();

    const targetId = this.getAttribute("href");
    if (targetId === "#") return;

    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({
        behavior: "smooth",
      });
    }
  });
});
