<?php
session_start();
$errors = [];

// Database configuration
$host = "sql102.infinityfree.com";
$user = "if0_38695849";
$pass = "rMW5q8eRAbxBe8"; 
$dbname = "if0_38695849_shopping";

// Create connection without selecting the database
$conn = mysqli_connect($host, $user, $pass);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Select the database
//mysqli_select_db($conn, $dbname);

// Create product_selections table if it doesn't exist
$tableCreationQuery = "
CREATE TABLE IF NOT EXISTS product_selections (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    size VARCHAR(10) NOT NULL,
    quality ENUM('High', 'Medium', 'Low') NOT NULL,
    product_type VARCHAR(50) NOT NULL,
    price varchar(255) NOT NULL
)";

// Alter the table to change the price column to VARCHAR
$alterTableQuery = "ALTER TABLE product_selections MODIFY price VARCHAR(255);";
if (mysqli_query($conn, $alterTableQuery)) {
   // echo "Table altered successfully.<br>";
} else {
    echo "Error altering table: " . mysqli_error($conn) . "<br>";
}

$quer="ALTER TABLE product_selections ADD created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP";
if(mysqli_query($conn,$quer)){
    //echo("successfully add");
}
else{
  // echo "failed to add".mysqli_error($conn);
}

if (!mysqli_query($conn, $tableCreationQuery)) {
    echo "Error creating table: " . mysqli_error($conn);
}

// Handle product selection form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    // Debugging: Print POST data
    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";

    // Validate and sanitize input
    $size = isset($_POST['size']) ? trim($_POST['size']) : '';
    $quality = isset($_POST['quality']) ? trim($_POST['quality']) : '';
    $product_type = isset($_POST['product_type']) ? trim($_POST['product_type']) : '';
    $price = isset($_POST['price']) ? trim($_POST['price']) : '';

    // Check if all fields are filled
    if (empty($size) || empty($quality) || empty($product_type) || empty($price)) {
        $errors[] = "All fields are required.";
    }

    // If no errors, insert into database
    if (empty($errors)) {
        // Prepare the SQL statement
        $stmt = mysqli_prepare($conn, "INSERT INTO product_selections (size, quality, product_type, price) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . mysqli_error($conn));
        }

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "ssss", $size, $quality, $product_type, $price);

        // Execute the statement
        if (mysqli_stmt_execute($stmt)) {
          //  echo "<p style='color:green;'>Product selection added successfully.</p>";

          header("Location: contactus.php");

        } else {
            echo "<p style='color:red;'>Error adding selection: " . mysqli_error($conn) . "</p>";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        // Display errors
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
        }
    }
}


// Close connection
mysqli_close($conn);
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>online shoping</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
     rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous">
      <link rel="stylesheet" href="style.css">
      <!-- FontAwesome CDN -->
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet">

<script src="https://kit.fontawesome.com/your-unique-kit-code.js" crossorigin="anonymous"></script>


</head>
<body>
<section class="header " id="header">
 <nav class="navbar navbar-expand-lg bg-secondary">
   <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll"
     aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active " aria-current="page" href="#header">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="#contact">contact</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle  " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            workspace
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#signup" class="a">signup</a></li>
            <li><a class="dropdown-item" href="#login" class="a">login</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="main.php" class="a">get all service</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="#about" class="nav-link  " aria-disabled="true">about me</a>
        </li>
        <h4>marelign.yimer</h4>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
      <img src="images/me.jpg" class="rounded-circle px-2 pl-0" height=60 width=55>
    </div>
  </div>
  </nav>
</section>

<!-- Add this toggle button to your navbar or any desired location -->
<div class="form-check form-switch  bg-success " >
    <input class="form-check-input" type="checkbox" id="darkModeToggle">
    <label class="form-check-label text-light" for="darkModeToggle">Dark Mode</label>
</div>
<center><section class="form  bg-secondary-subtle" id="signup">
            <form method="post" action="signup.php" class="p-3" name="myform">
                 <h2>Signup here</h2>

                 <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($_SESSION['errors'] as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                    <?php unset($_SESSION['errors']); // Clear errors after displaying them ?>
                <?php endif; ?>
    
      
    Name: <input type="text" name="name" class="name" required placeholder="Enter your name"><br>
    Father's Name: <input type="text" name="fname" class="fname" required placeholder="Enter your father's name"><br>
    Email: <input type="email" name="email" placeholder="Email" class="email" required><br>
    Gender: <input type="radio" name="gender" value="male" required> Male
    <input type="radio" name="gender" value="female" required> Female<br><br>
    Password: <input type="password" name="password" class="password" placeholder="Enter password" required><br>
    Confirm Password: <input type="password" name="password2" class="password2" placeholder="Confirm password" required><br>
    <input type="submit" name="signup" value="Signup" class="signup btn btn-info"><br><br>
    If you have an account: <a href="#login" class="btn btn-info pt-2">Login</a>
   </form>  </div>
        <!-- </div> -->
    
  </section> </center>

    <section class="login p-3 bg-secondary-subtle my-2" id="login">
        <div class="row">
            <div class="col-md-10">
                <div class="form" id="login">
                </div> 
   <form method="post" action="login.php" name="login">
                   <h2>Login here</h2>
                   <!-- Put this where you want the logout button to appear -->
                   <button type="submit" name="logout" class="btn btn-danger">Logout</button>
    <!-- Display email and password from cookies if available -->
     
    Email: <input type="email" name="email" placeholder="Enter your email" required><br><br>
    Password: <input type="password" name="password" placeholder="Enter your password" required><br><br>
        <input type="submit" name="login" value="Login" class="login btn btn-success">
    If you do not have an account, please <a href="#signup" class="btn btn-success">Signup</a>
     </form>

            </div>
        </div>
   </section>
<section class="about bg-light m-2" id="about">
      <center>  <h3>about me</h3></center>
        <div class="row gap-5">
         <div class="col-md-4 bg-danger-subtle">
          <div class="card" style="width: 18rem;">
           <img src="images/kobo.jpg" class="card-img-top rounded img-fluid" alt="..." >
             <div class="card-body">
            <h5 class="card-title">instructer of this website:Marelign Yimer</h5>
         <p class="card-text">
            dou you know about this?you can learn tecneology freely in every where and any time
            by using ur hand mobile or laptop
            
    <a href="http://maruman.free.nf/?i=1" class="btn btn-primary">more about</a>
  </div>
    </div></div>
       <div class="col-md-3 bg-dark">
        <div class="card" style="width:14rem">
          <img src="images/bdu.jpg" class="card-img-top" alt="...">
              <div class="card-body">
    <h5 class="card-title">instructer of this website:Marelign Yimer</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.
    if u more interested to learn tech start by signup first and creat acount and next by hiting tutorial
    button you can get d/t front and back end courses including database and d/t frame work
    </p>
    <a href="https://github.com/mareligncode/online-shopping-fullstack-project" class="btn btn-primary">details</a>
  </div>
       </div>
        </div>

     <div class="col-md-3 bg-warning-subtle">
     <div class="card" style="width: 18rem;">
      <img src="images/BDU2123.jpg" class="card-img-top" alt="...">
     <div class="card-body">
    <h5 class="card-title">instructer of this website:Marelign Yimer</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="https://github.com/mareligncode/photograph-website-front-end" class="btn btn-primary">studio</a>    </div>
      </div>
      </div>
 </section>

 <!-- calculator -->



</section >
<section id="service" class="bg-dark text-light service p-0">
<!-- services ection -->
<p >to get all service please first signup or login by your acound</p>
                       
 <!-- Contact Section -->
 </section>


 <section class="contact bg-light" id="contact">

    <p>to get contact section sgin up and select product! or login by yor acount</P>
</section>

<!-- footer section -->

<section>
     <footer class="bg-dark text-white py-4">
    <div class="container">
        <div class="row">
            <!-- Left Section -->
            <div class="col-md-6">
                <p>&copy; <span id="year"></span>marelign yimer. All Rights Reserved.</p>
            </div>
            <!-- Right Section (Social Media Links) -->
            <div class="col-md-6 text-end">
                <a href="https://www.facebook.com/profile.php?id=100070214702976&mibextid=rS40aB7S9Ucbxw6v" class="text-white mx-2" target="_blank">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="https://www.instagram.com/ma.y4534" class="text-white mx-2" target="_blank">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://www.tiktok.com/@maru.man1?_t=ZM-8tzPMST9y8U&_r=1" class="text-white mx-2" target="_blank">
                    <i class="fab fa-tiktok"></i>
                </a>
                <a href="https://t.me/marelignY" class="text-white mx-2" target="_blank">
                <i class="fab fa-telegram-plane"></i>
                <a href="mailto:yimermarelign@gmail.com-email@gmail.com" class="text-white mx-2">
                    <i class="fas fa-envelope"></i>
                </a>

                <a href="https://github.com/mareligncode/online-shopping-fullstack-project"><i class="fab fa-github"></i></a>
                <a href="http://www.youtube.com/@MarelignYimer-n6n"><i class="fab fa-youtube"></i></a>


                <a href="tel:+123456789" class="text-white mx-2">
                    <i class="fas fa-phone-alt">-251 945342453</i>
                </a>
            </div>
        </div>
    </div>
  </footer>
</section>


<script>
// Dark Mode Toggle Script
const darkModeToggle = document.getElementById("darkModeToggle");

// Check localStorage for user's preference on page load
document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        darkModeToggle.checked = true;
    }
});

// Toggle dark mode on button click
darkModeToggle.addEventListener("change", () => {
    const body = document.body;
    body.classList.toggle("dark-mode");

    // Save the user's preference in localStorage
    if (body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
    } else {
        localStorage.setItem("darkMode", "disabled");
    }
});
document.getElementById('year').textContent = new Date().getFullYear();

</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
          integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
           crossorigin="anonymous"></script>
  
</body>
</html>
