<?php
// Ensure you're using the correct password for MySQL root user.
$conn = mysqli_connect("sql102.infinityfree.com", "if0_38695849","rMW5q8eRAbxBe8", "if0_38695849_shopping"); // Use correct password here

if (!$conn) {
    die("Unable to connect: " . mysqli_connect_error());
} 

// Correct CREATE TABLE statement
$table = "CREATE TABLE women_service (
    id INT(11) AUTO_INCREMENT PRIMARY KEY, 
    fullname VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(100),
    category VARCHAR(100),
    level VARCHAR(50),
    typeofjeans VARCHAR(100),
    typeofshoes VARCHAR(100),
    typeofdress VARCHAR(100),
    typeoftshirt VARCHAR(100),
    size VARCHAR(100),
    color VARCHAR(100)
)";

if (mysqli_query($conn, $table)) {
   // echo "Table successfully created";
} else {
   // die("Error creating table: " . mysqli_error($conn));
}
$alter="alter table women_service add timeofmarket timestamp default current_timestamp";
if(mysqli_query($conn,$alter)){
 //   echo "one column add";
}
else{
   //die("error adding column".mysqli_error($conn));
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit'])){
  $fullname=$_POST['fullname']; 
  $emailadress=$_POST['emailadress'];
  $phone=$_POST['phone'];
  //$catagory=isset($_POST['category'])?$_POST['category']:'';
  $catagory = isset($_POST['catagory']) ? $_POST['catagory'] : '';
  $level=isset($_POST['level'])?$_POST['level']:'';
  $jeanstype=isset($_POST['jeanstype']) ?$_POST['jeanstype']:'';
 $shosetype = isset($_POST['shoseType']) ? $_POST['shoseType'] : ''; // Safely accessing
    $dresstype = isset($_POST['dresstype']) ? $_POST['dresstype'] : ''; // Safely accessing
    $tishrttype = isset($_POST['tishrttype']) ? $_POST['tishrttype'] : ''; 
  $size=$_POST['size'];
  $color=$_POST['color'];
$stmet = mysqli_prepare($conn, "INSERT INTO women_service (fullname, email, phone, category, level, typeofjeans,
typeofshoes, typeofdress, typeoftshirt, size, color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmet === false) {
   die("MySQL prepare error: " . mysqli_error($conn)); // Error checking for prepare
}

mysqli_stmt_bind_param($stmet, "sssssssssss", $fullname, $emailadress, $phone, $catagory, $level, $jeanstype,
$shosetype, $dresstype, $tishrttype, $size, $color);

if (mysqli_stmt_execute($stmet)) { // Corrected spelling
    echo "Successfully inserted.";
    header("Location: contactus.php");
    exit;
} else {
    die("Error executing statement: " . mysqli_stmt_error($stmet)); // Add error handling for execute
}


}
// Close the connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FashionHub - Online Clothing Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="main.css">

        
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#categories">Categories</a>
                    </li>
                   
   
                </ul>
            
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <h1 class="display-3 fw-bold">fasion collection of 2025</h1>
            <p class="lead">Discover the latest trends in fashion</p>
        </div>
    </section>
    
    <!-- Categories Section -->
    <section id="categories" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Shop by Category</h2>
            <div class="row">
               
<div class="col-md-3">
    <div class="card category-card">
        <img src="img/jeans3.jpg" class="card-img-top" alt="Women's Jeans">
        <div class="card-body text-center">
            <h5 class="card-title">Women's Jeans</h5>
            <h6>level one</h6>
            <button class="btn btn-outline-primary view-all-btn" data-category="jeans">View All</button>
        </div>
    </div>
</div>

<div class="col-md-3">
    <div class="card category-card">
        <img src="img/shose3.jpg" class="card-img-top" alt="Women's Shoes">
        <div class="card-body text-center">
            <h5 class="card-title">Women's Shoes</h5>
            <h6>level one</h6>
  <button class="btn btn-outline-primary view-all-btn" data-category="shoes">View All</button>
        </div>
    </div>
</div>

<div class="col-md-3">
    <div class="card category-card">
        <img src="img/dress3.jpg" class="card-img-top" alt="Women's Dresses">
        <div class="card-body text-center">
            <h5 class="card-title">Women's Dresses</h5>
            <h6>level one</h6>
            <button class="btn btn-outline-primary view-all-btn" data-category="dress">View All</button>
        </div>
    </div>
</div>

<div class="col-md-3">
    <div class="card category-card">
        <img src="img/tishrt3.jpg" class="card-img-top" alt="Women's T-Shirts">
        <div class="card-body text-center">
            <h5 class="card-title">Women's T-Shirts</h5>
            <h6>level one</h6>
            <button class="btn btn-outline-primary view-all-btn" data-category="t-shirt">View All</button>
        </div>
    </div>
</div>
               
                </div>
            </div>
        </div>
    </section>
    <section class="buy py-5" id="">
    <div class="container">
        <h2 class="text-center mb-4 text-light">Fill to Buy</h2>
        <form method="post" action="main.php" class="mx-auto bg-dark-subtle rounded p-4 shadow" style="max-width: 600px;">
            <div class="mb-3">
                <label for="fullname" class="form-label">Full Name:</label>
                <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Enter your name" required>
            </div>
            <div class="mb-3">
                <label for="emailadress" class="form-label">Email:</label>
                <input type="email" class="form-control" id="emailadress" name="emailadress" placeholder="Email" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone:</label>
                <input type="number" class="form-control" id="phone" name="phone" placeholder="-2519" required>
            </div>
            <div class="mb-3">
                <label for="catagory" class="form-label">Category:</label>
                <select name="catagory" id="catagory" class="form-select" required>
                    <option value="jeans">Jeans</option>
                    <option value="dress">Dress</option>
                    <option value="shoes">Shoes</option>
                    <option value="tshirt">T-Shirt</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="level" class="form-label">Level:</label>
                <select name="level" id="level" class="form-select" required>
                    <option value="levelone">Level One</option>
                    <option value="leveltwo">Level Two</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">typeof jeans:</label>
                <select name="jeanstype" id="jeanse" class="form-select" >
                    <option value="" disabled selected>test</option>
                    <option value="skinny">skinny jeans</option>
                    <option value="bootcut">bootcut jeans</option>
                    <option value="high waist">hight waist jeans</option>
            <option value="ripped jeans">ripped jeans</option>
                   
                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">typeof shose:</label>
                <select name="shoseType" id="shose" class="form-select" >
                <option value="" disabled selected>test</option>
                    <option value="running_shose">running shose</option>
                    <option value="casual_snicker">casual snicker</option>
                    <option value="hight heels">hight heels</option>
                    <option value="boots">boots</option>

                   
                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">typeof dress:</label>
                <select name="dresstype" id="size" class="form-select" >
                <option value="" disabled selected>test</option>
                    <option value="summer dress">summer dress</option>
                    <option value="evning grown">evning grown</option>
                    <option value="casual dress">party dress</option>
                    <option value="festiva dress">festival dress</option>

                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">typeof tishert:</label>
                <select name="tishrttype" id="size" class="form-select" >
                <option value="" disabled selected>test</option>
                    <option value="basic"> basic t-shirt</option>
                    <option value="graphic">graphic tee</option>
                    <option value="v neck">v neck t-shirt</option>
                    <option value="long sleeve">long sleeve tee</option>

                   
                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">Size:</label>
                <select name="size" id="size" class="form-select" >
                    <option value="s">Small</option>
                    <option value="md">Medium</option>
                    <option value="l">Large</option>
                    <option value="xl">Extra Large</option>
                    <option value="xxl">Extra Extra Large</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="emailadress" class="form-label">color:</label>
                <input type="text" class="form-control" id="emailadress" name="color" placeholder="color" >
            </div>
            <button type="submit" class="btn btn-primary w-100" name="submit">Submit selection</button>
        </form>
    </div>
</section>

   
  

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="mainn.js"></script>

    
</body>
</html>